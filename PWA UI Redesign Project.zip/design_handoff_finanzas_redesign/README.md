# Handoff: Finanzas — Inicio & Gastos Redesign (Light Mode)

## Overview
Light-mode redesign of two screens of the Finanzas couples-finance app: **Inicio** (home dashboard) and **Gastos** (transaction list). Goal: cleaner, more polished, minimalist visual hierarchy while keeping the app's Spanish-first, warm/direct voice.

## About the Design Files
The bundled file (`Finanzas Redesign.dc.html`) is a **design reference built in HTML** — a static high-fidelity mockup showing intended look, layout, and copy. It is not production code. Recreate it in the target codebase's existing stack (per the design system: React + TypeScript + Zustand + Zod + Tailwind + Motion) using existing components/patterns where they exist, extending them for light mode where they don't yet.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy below are final; recreate pixel-close using the app's existing component patterns.

## Screens

### 1 — Inicio
- **Purpose**: Daily glanceable view of personal + shared financial health.
- **Layout** (top to bottom, 16px side padding, iPhone 390–402px width):
  1. Header row: greeting ("Buenas tardes") + big name in Fraunces 150 weight, 34px, next to a circular settings button (40px, white, hairline border, soft shadow).
  2. Person switcher: pill-shaped segmented control (Víctor / Camila), track white with hairline border; active option gets a light tint background matching that person's identity color, a colored border, and a small circular avatar.
  3. **Bienestar financiero** card — bg near-black `#16160F` (floats on the light page bg, only card that stays dark), radius 12px, padding 20px:
     - Row 1: uppercase label "Bienestar financiero" + a small toggle switch (blue, on).
     - Row 2: donut ring (88px, conic-gradient blue `#4B7FFA` for the filled %, `#2E2E2C` remainder) with centered "82%" text, next to the big amount ($9.325.000, 32px, weight 300, tabular nums) and subcaption "sin comprometer".
     - Hairline divider, then a 3-column stat row: Ingresos / Gastos pers. / Compartido, each an uppercase 11px label + 15px tabular amount (Ingresos and Compartido colored blue, Gastos pers. neutral white).
     - Hairline divider, then a "Distribución" row: label + inline legend text ("Vivienda 71% · Alimentación 29%"), and a 6px-tall two-segment bar (blue / yellow-green `#C9F23D`) below.
  4. **Hogar compartido** row — compact card (not a big card), white bg, soft shadow, radius 12px: leading 36px icon tile (house glyph), title + "100%" percentage, thin 4px progress bar, and a footer line with the amount ("$2.475.000 de $2.475.000") plus two small overlapping avatar circles (V blue, C pink).
  5. Filter chips: horizontal scroll row, "Todas" active (filled near-black pill, white text), others are white pills with a small colored dot + label (Vivienda/Alimentación/Transporte).
  6. Section label "Movimientos recientes" (uppercase, 11px, secondary gray).
  7. Transaction rows (see **Transaction row** spec below).
  8. Floating FAB "+ Agregar" bottom-right, pill, near-black bg, white text/icon, shadow.
  9. Bottom nav: frosted glass pill bar (4 tabs: Inicio/Gastos/Metas/Perfil), active tab icon+label in blue, inactive in muted gray.

### 2 — Gastos
- **Purpose**: Filterable list of all transactions.
- **Layout**: same header pattern (title "Gastos" in Fraunces instead of name) → single summary card ("Gastos de Víctor": total amount + este mes caption, then Personal / Compartido split columns) → same filter chips → "Todos los movimientos" label with a count on the right ("2 gastos") → transaction rows → FAB "+ Agregar gasto" → same bottom nav with Gastos tab active.

### Transaction row (shared component)
Flat row, white bg, hairline border + soft double shadow (`0 1px 2px rgba(20,20,15,.04), 0 4px 12px rgba(20,20,15,.05)`), radius 12px, padding 12x16, gap 12px:
- Leading 40x40 icon tile, radius 10, bg = light tint of the category color, containing a single category emoji (🏠 vivienda, 🛒 alimentación — emoji are user-assignable per category, matching existing app convention).
- Middle: name (15px, weight 400) + meta line (small colored dot matching category color + "Categoría · ownership" in 12px secondary gray).
- Trailing: amount right-aligned (16px, weight 300, tabular nums); if the expense is shared, a second line below in the accent blue: "Mi parte $X".
- **Do not** use a floating vertical color bar on the left edge of the row — that was tried and rejected as visually noisy; the category dot + icon tint carry that signal instead.

## Design Tokens
- Background (page): `#F5F4F1`
- Card surface: `#FFFFFF`, hairline border `rgba(20,20,15,0.08)` (or `0.06` on list rows), shadow `0 1px 2px rgba(20,20,15,.04), 0 4px 12px rgba(20,20,15,.05)`
- Hero/dark card bg: `#16160F` (text on it: `#F5F5F3` primary, `#9A9A93` secondary)
- Text: primary `#16160F`, secondary `#6B6A63`, muted `#A8A6A0`
- Accent blue (CTA / shared): `#4B7FFA`; readable-on-white variant for small text/links: `#3A66D6`
- Víctor identity: `#38BDF8` (tint bg `#E7F4FC`)
- Camila identity: `#D4537E` (tint bg `#F6E1E9`)
- Vivienda category: blue `#4B7FFA` (icon tile tint `#E7F4FC`)
- Alimentación category: readable yellow-green `#8FAF00` (icon tile tint `#F2F7DC`); the raw brand yellow `#C9F23D` is used only for the wide distribution bar segment, not for small text/dots on white (contrast).
- Transporte category: coral `#D85A30`
- Radius: input/control 8px, card/row 12px, pill 999px, avatar 50%
- Typography: Fraunces (weight 150) for the big greeting/title only; Inter for everything else. Amounts: weight 300, tabular-nums, letter-spacing -0.03em. Uppercase labels: 11px, weight 500, letter-spacing 0.09em.

## Interactions & Behavior
Static mockup — no functional interactivity was built (filters, toggle, and person switcher are visual only). Expected real behavior once implemented:
- Filter chips filter the transaction list by category.
- Person switcher pill toggles the whole Inicio view between Víctor's and Camila's personal figures (shared figures stay the same).
- The "Bienestar financiero" toggle is a display preference switch (exact behavior TBD — confirm with design/PM).
- FAB opens the existing "Agregar gasto" bottom sheet flow.

## Assets
No external image assets — all icons are inline SVG (stroke-based, ~1.75px stroke, rounded caps, matching the app's Lucide icon convention) and category icons are plain emoji, consistent with the existing design system's "user-assigned emoji per category" convention.

## Files
- `Finanzas Redesign.dc.html` — the design reference (renders two iPhone-frame mockups: Inicio and Gastos). Open in a browser to view.
